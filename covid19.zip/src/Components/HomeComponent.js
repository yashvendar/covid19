import React, { Component } from 'react';
class Home extends Component{
    render(){
        return(
            <></>
        )
    }
}
export default Home;