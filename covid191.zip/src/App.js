import React from 'react';
import './App.css';
import Main from './Components/MainComponent';

function App() {
  return (
    <div className="App">
      <Main />
    </div>
  );
}

export default App;
